package com.example.desbinarconta;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(11, 7, 18);
    private final int PANEL = Color.rgb(23, 13, 35);
    private final int PURPLE = Color.rgb(126, 34, 206);
    private final int LAVENDER = Color.rgb(216, 180, 254);
    private final int MUTED = Color.rgb(167, 139, 250);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        showLogin();
    }

    private GradientDrawable shape(int color, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        if (stroke != 0) d.setStroke(2, stroke);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private void showLogin() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(28, 32, 28, 32);
        root.setBackgroundColor(BG);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(24, 28, 24, 24);
        card.setBackground(shape(PANEL, Color.rgb(113, 56, 184), 32));
        card.setElevation(12);

        TextView emblem = text("✦", 34, LAVENDER, true);
        emblem.setBackground(shape(Color.rgb(41, 17, 63), 0, 28));
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(76, 76);
        ep.bottomMargin = 18;
        card.addView(emblem, ep);

        TextView title = text("DESBINAR CONTA", 23, LAVENDER, true);
        card.addView(title, matchWrap());
        TextView subtitle = text("KEYAUTH AUTHENTICATION", 11, MUTED, true);
        LinearLayout.LayoutParams sp = matchWrap();
        sp.topMargin = 8; sp.bottomMargin = 28;
        card.addView(subtitle, sp);

        TextView label = text("License Key", 14, Color.rgb(221,214,254), false);
        label.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        card.addView(label, matchWrap());

        EditText key = new EditText(this);
        key.setSingleLine(true);
        key.setTextSize(14);
        key.setTextColor(Color.WHITE);
        key.setHintTextColor(Color.rgb(139,130,152));
        key.setHint("Insira sua key...");
        key.setPadding(16, 10, 16, 10);
        key.setBackground(shape(Color.rgb(23,13,35), Color.rgb(109,40,168), 18));
        LinearLayout.LayoutParams kp = matchWrap();
        kp.topMargin = 8; kp.bottomMargin = 18;
        card.addView(key, kp);

        Button enter = new Button(this);
        enter.setText("ENTRAR");
        enter.setTextColor(Color.WHITE);
        enter.setTextSize(14);
        enter.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        enter.setBackground(shape(PURPLE, 0, 18));
        card.addView(enter, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 54));
        enter.setOnClickListener(v -> Toast.makeText(this,
            "Prévia visual: autenticação não configurada.", Toast.LENGTH_SHORT).show());

        TextView version = text("DESBINAR CONTA  •  V1.0", 10,
            Color.rgb(113,98,127), false);
        LinearLayout.LayoutParams vp = matchWrap();
        vp.topMargin = 24;
        card.addView(version, vp);

        root.addView(card, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(root);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }
}
